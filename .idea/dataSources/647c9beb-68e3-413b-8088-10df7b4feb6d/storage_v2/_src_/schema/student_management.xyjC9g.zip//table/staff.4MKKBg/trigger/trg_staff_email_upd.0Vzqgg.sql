create definer = root@localhost trigger trg_staff_email_upd
    after update
    on staff
    for each row
BEGIN
    IF NEW.email IS NOT NULL AND NEW.email <> '' THEN
        UPDATE users SET email = NEW.email WHERE user_id = NEW.user_id;
    END IF;
END;

