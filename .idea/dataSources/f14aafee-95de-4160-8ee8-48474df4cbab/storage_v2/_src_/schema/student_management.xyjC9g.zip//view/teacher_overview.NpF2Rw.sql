create definer = root@localhost view teacher_overview as
select `t`.`teacher_id`                                                                             AS `teacher_id`,
       `t`.`teacher_code`                                                                           AS `teacher_code`,
       `t`.`teacher_name`                                                                           AS `teacher_name`,
       `t`.`email`                                                                                  AS `email`,
       `t`.`phone`                                                                                  AS `phone`,
       `t`.`salary`                                                                                 AS `salary`,
       `u`.`status`                                                                                 AS `status`,
       group_concat(distinct `sub`.`subject_name` order by `sub`.`subject_name` ASC separator
                    ', ')                                                                           AS `subjects_taught`,
       `cls`.`class_name`                                                                           AS `class_leader_of`
from ((((`student_management`.`teachers` `t` join `student_management`.`users` `u`
         on ((`t`.`user_id` = `u`.`user_id`))) left join `student_management`.`teacher_subjects` `ts`
        on ((`ts`.`teacher_id` = `t`.`teacher_id`))) left join `student_management`.`subjects` `sub`
       on ((`sub`.`subject_id` = `ts`.`subject_id`))) left join `student_management`.`classes` `cls`
      on ((`cls`.`class_teacher_id` = `t`.`teacher_id`)))
group by `t`.`teacher_id`, `t`.`teacher_code`, `t`.`teacher_name`, `t`.`email`, `t`.`phone`, `t`.`salary`, `u`.`status`,
         `cls`.`class_name`;

