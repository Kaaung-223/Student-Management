create definer = root@localhost view student_academic_summary as
select `s`.`student_id`                                                                AS `student_id`,
       `s`.`student_name`                                                              AS `student_name`,
       `s`.`student_code`                                                              AS `student_code`,
       `c`.`class_name`                                                                AS `class_name`,
       `c`.`academic_year`                                                             AS `start_academic_year`,
       concat(`c`.`academic_year`, ' - ', (cast(`c`.`academic_year` as unsigned) + 1)) AS `academic_year_range`
from (`student_management`.`students` `s` left join `student_management`.`classes` `c`
      on ((`s`.`class_id` = `c`.`class_id`)));

