create definer = root@localhost view student_attendance_summary as
select `s`.`student_id`                                              AS `student_id`,
       `s`.`student_name`                                            AS `student_name`,
       `s`.`class_id`                                                AS `class_id`,
       `c`.`class_name`                                              AS `class_name`,
       count(`a`.`attendance_id`)                                    AS `total_days`,
       sum((case when (`a`.`status` = 'Present') then 1 else 0 end)) AS `present_count`,
       sum((case when (`a`.`status` = 'Absent') then 1 else 0 end))  AS `absent_count`,
       sum((case when (`a`.`status` = 'Late') then 1 else 0 end))    AS `late_count`,
       round(ifnull(((sum((case when (`a`.`status` = 'Present') then 1 else 0 end)) * 100.0) /
                     nullif(count(`a`.`attendance_id`), 0)), 0), 2)  AS `attendance_percentage`
from ((`student_management`.`students` `s` left join `student_management`.`classes` `c`
       on ((`s`.`class_id` = `c`.`class_id`))) left join `student_management`.`attendance` `a`
      on ((`s`.`student_id` = `a`.`student_id`)))
group by `s`.`student_id`, `s`.`student_name`, `s`.`class_id`, `c`.`class_name`;

