create definer = root@localhost view student_gpa_summary as
select `s`.`student_id`                AS `student_id`,
       `s`.`student_name`              AS `student_name`,
       `s`.`class_id`                  AS `class_id`,
       `c`.`class_name`                AS `class_name`,
       round(avg(`g`.`percentage`), 2) AS `gpa`,
       count(`g`.`grade_id`)           AS `total_exams_taken`
from ((`student_management`.`students` `s` left join `student_management`.`classes` `c`
       on ((`s`.`class_id` = `c`.`class_id`))) left join `student_management`.`grades` `g`
      on ((`s`.`student_id` = `g`.`student_id`)))
group by `s`.`student_id`, `s`.`student_name`, `s`.`class_id`, `c`.`class_name`;

