create definer = root@localhost view exam_overview as
select `e`.`exam_id`         AS `exam_id`,
       `e`.`exam_name`       AS `exam_name`,
       `e`.`class_id`        AS `class_id`,
       `c`.`class_name`      AS `class_name`,
       `e`.`exam_date`       AS `exam_date`,
       `e`.`total_marks`     AS `total_marks`,
       count(`g`.`grade_id`) AS `grades_recorded`
from ((`student_management`.`exams` `e` left join `student_management`.`classes` `c`
       on ((`c`.`class_id` = `e`.`class_id`))) left join `student_management`.`grades` `g`
      on ((`g`.`exam_id` = `e`.`exam_id`)))
group by `e`.`exam_id`, `e`.`exam_name`, `e`.`class_id`, `c`.`class_name`, `e`.`exam_date`, `e`.`total_marks`;

